package software.bernie.geckolib.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import software.bernie.geckolib.GeckoLibClient;
import software.bernie.geckolib.GeckoLibServices;
import software.bernie.geckolib.network.packet.MultiloaderPacket;
import software.bernie.geckolib.service.GeckoLibNetworking;

/**
 * Fabric service implementation for GeckoLib's networking functionalities
 */
public final class GeckoLibNetworkingFabric implements GeckoLibNetworking {
    /**
     * Register a GeckoLib packet for use
     * <p>
     * <b><u>FOR GECKOLIB USE ONLY</u></b>
     */
    @Override
    public <B extends class_2540, P extends MultiloaderPacket> void registerPacketInternal(class_8710.class_9154<P> payloadType, class_9139<B, P> codec, boolean isClientBound) {
        if (isClientBound) {
            PayloadTypeRegistry.playS2C().register(payloadType, (class_9139<class_2540, P>)codec);

            if (GeckoLibServices.PLATFORM.isPhysicalClient())
                GeckoLibClient.registerPacket(payloadType);
        }
        else {
            PayloadTypeRegistry.playC2S().register(payloadType, (class_9139<class_2540, P>)codec);
            ServerPlayNetworking.registerGlobalReceiver(payloadType, (packet, context) -> packet.receiveMessage(context.player(), context.player().method_5682()::execute));
        }
    }

    /**
     * Send a packet to all players currently tracking a given entity
     * <p>
     * Good as a shortcut for sending a packet to all players that may have an interest in a given entity or its dealings
     * <p>
     * Will also send the packet to the entity itself if the entity is also a player
     */
    @Override
    public void sendToAllPlayersTrackingEntity(MultiloaderPacket packet, class_1297 trackingEntity) {
        if (trackingEntity instanceof class_3222 pl)
            sendToPlayer(packet, pl);

        for (class_3222 player : PlayerLookup.tracking(trackingEntity)) {
            sendToPlayer(packet, player);
        }
    }

    /**
     * Send a packet to all players tracking a given block position
     */
    @Override
    public void sendToAllPlayersTrackingBlock(MultiloaderPacket packet, class_3218 level, class_2338 pos) {
        for (class_3222 player : PlayerLookup.tracking(level, pos)) {
            sendToPlayer(packet, player);
        }
    }

    /**
     * Send a packet to the given player
     */
    @Override
    public void sendToPlayer(MultiloaderPacket packet, class_3222 player) {
        ServerPlayNetworking.send(player, packet);
    }
}
